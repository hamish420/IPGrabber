import socket    

host = socket.gethostname()    
IP  = socket.gethostbyname(host) 


print(f"Your Computer Name is: {host}")    
print(f"Your Computer IP Address is: {IP}") 
